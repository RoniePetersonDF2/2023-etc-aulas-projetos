<?php

$dsn = 'mysql:host=127.0.0.1;dbname=ouvir_etc_db;charset=utf8;';

$conn = new PDO($dsn, 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$query = 'DELETE FROM usuarios WHERE id = :id';
$stmt = $conn->prepare($query);
$stmt->bindValue(':id', $_GET['id'], PDO::PARAM_INT);

if ($stmt->execute()) {
    header('location: usuario.php');
    exit();
} else {
    echo $conn->errorInfo();
}

var_dump($_POST);

