<?php

$dsn = 'mysql:host=127.0.0.1;dbname=ouvir_etc_db;charset=utf8;';

$conn = new PDO($dsn, 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$id = $_GET['id'] ?? 0;

$query = 'SELECT * FROM ouvir_etc_db.usuarios WHERE id = :id;';
$stmt = $conn->prepare($query);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$usuario) {
    header('Location: usuario.php?message=Relato não encontrado.');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <main>


        <h1>Usuário - Nº: <?= $usuario['id']; ?></h1>

        <hr>

        <ul>
            <li>
                <h2>Nome</h2>
                <p><?= $usuario['nome']; ?></p>
            </li>

            <li>
                <h2>E-mail</h2>
                <p><?= $usuario['email']; ?></p>
            </li>

            <li>
                <h2>Tipo</h2>
                <p><?= $usuario['tipousuario']; ?></p>
            </li>

            <li>
                <h2>Status</h2>
                <p><?= $usuario['statususuario']; ?></p>
            </li>
        </ul>

        <br>
        <hr>
        <br>
        <a href="usuario.php" class="btn btn-voltar">Voltar</a>
    </main>
</body>

</html>