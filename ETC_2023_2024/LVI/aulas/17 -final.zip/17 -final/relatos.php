<?php
require 'restritos.php';

if (isPerfilUsuario())
{
    header('location: login.php?message=Usuário não tem permissão para acessar.');
    exit();
}

$dsn = 'mysql:host=127.0.0.1;dbname=ouvir_etc_db;charset=utf8;';

$conn = new PDO($dsn, 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$query = 'SELECT * FROM ouvir_etc_db.relatos ORDER BY dataabertura desc, tipo;';
$stmt = $conn->query($query);
$relatos = $stmt->fetchAll(PDO::FETCH_ASSOC);
$count = 0;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <main>

        <h1>Relatos</h1>

        <table>
            <thead>
                <th>#</th>
                <th>Data de Abertura</th>
                <th>Tipo</th>
                <th>Status</th>
                <th>Título</th>
                <th>Ação</th>
            </thead>

            <tbody>
                <?php if ($relatos) : ?>
                    <?php foreach ($relatos as $relato) :
                        $count++; ?>
                        <tr>
                            <td><?= $count; ?></td>
                            <td><?= htmlspecialchars($relato['dataabertura']); ?></td>
                            <td><?= htmlspecialchars($relato['tipo']); ?></td>
                            <td><?= htmlspecialchars($relato['status']); ?></td>
                            <td><?= htmlspecialchars($relato['titulo']); ?></td>
                            <td>
                                <a href="relato-show.php?id=<?= $relato['id'] ?>">Detalhar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6">Não existem registros cadastrados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <th colspan="6">
                        Total de registros: <?= $count; ?>
                    </th>
                </tr>
            </tfoot>
        </table>
    </main>
</body>

</html>