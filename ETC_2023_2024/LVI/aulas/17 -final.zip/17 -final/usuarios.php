<?php
$dsn = 'mysql:host=127.0.0.1;dbname=ouvir_etc_db;charset=utf8;';

$conn = new PDO($dsn, 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$query = 'SELECT * FROM ouvir_etc_db.usuarios;';
$stmt = $conn->query($query);
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
$count = 0;
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <main>

        <h1>Usuários</h1>

        <div class="div-create">
            <a href="usuario-create.php" class="btn">Novo usuário</a>
        </div>
        <table>
            <thead>
                <th>#</th>
                <th>Nome</th>
                <th>E-nmail</th>
                <th>Tipo</th>
                <th>Ação</th>
            </thead>

            <tbody>
                <?php if ($usuarios) : ?>
                    <?php foreach ($usuarios as $usuario) :
                        $count++; ?>
                        <tr>
                            <td><?= $count; ?></td>
                            <td><?= htmlspecialchars($usuario['nome']); ?></td>
                            <td><?= htmlspecialchars($usuario['email']); ?></td>
                            <td><?= htmlspecialchars($usuario['tipousuario']); ?></td>
                            <td>
                                <a href="usuario-show.php?id=<?= $usuario['id'] ?>">Detalhar</a>
                                <a class="btn" href="usuario-delete.php?id=<?= $usuario['id'] ?>">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="5">Não existem registros cadastrados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>

            <tfoot>
                <tr>
                    <th colspan="6">
                        Total de registros: <?= $count; ?>
                    </th>
                </tr>
            </tfoot>
        </table>
    </main>
</body>

</html>