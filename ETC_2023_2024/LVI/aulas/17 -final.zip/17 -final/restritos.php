<?php
session_start();

function isUsuarioLogado()
{
    return isset($_SESSION['usuario']);
}

function isPerfilUsuario()
{
    return isUsuarioLogado() && $_SESSION['usuario']['tipousuario'] == 'USUARIO';
}

function isPerfilDiferenteDeUsuario()
{
    return isUsuarioLogado() && !isPerfilUsuario();
}

function getNomeUsuario()
{
    if (isUsuarioLogado()) {
        return $_SESSION['usuario']['nome'];
    }
}
