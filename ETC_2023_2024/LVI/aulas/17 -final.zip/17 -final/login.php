<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $dsn = 'mysql:host=127.0.0.1;dbname=ouvir_etc_db;charset=utf8;';

    $conn = new PDO($dsn, 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    $id = $_GET['id'] ?? 0;

    $query = 'SELECT * FROM ouvir_etc_db.usuarios 
                WHERE email = :email 
                AND password = :password';
    $stmt = $conn->prepare($query);
    $stmt->bindValue(':email', $email, PDO::PARAM_STR);
    $stmt->bindValue(':password', $password, PDO::PARAM_STR);
    $stmt->execute();
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$usuario) {
        header('Location: login.php?message=Usuário não encontrado.');
        exit();
    }

    $_SESSION['usuario'] = [
        'nome' => $usuario['nome'],
        'email' => $usuario['email'],
        'tipousuario' => $usuario['tipousuario'],
    ];
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <main>
        <h1>Login</h1>
        <?php if (isset($_GET['message'])): ?>
            <div class="message-error">
                <p><?=$_GET['message']; ?></p>
            </div>
        <?php endif;?>
        <form action="" method="post">
            <label for="email">E-mail</label>
            <input type="email" name="email" placeholder="Informe o e-mail." required autofocus>
            <label for="password">Password</label>
            <input type="password" name="password" placeholder="Informe sua senha." required>
            <button name="login" class="btn">Login</button>
            <a href="index.php" class="btn btn-voltar">Voltar</a>
        </form>
    </main>
</body>

</html>