<?php
require 'restritos.php';

$isUsuarioLogado = isUsuarioLogado();
$isAdminOrAnalista = isPerfilDiferenteDeUsuario();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <main>
        <header class="cabecalho">
            <h1>Relatos</h1>

            <div class="container-login-logout">
                <?php if ($isUsuarioLogado === false): ?>
                    <a href="login.php" class="btn-outros">Login</a>
                <?php else: ?>
                    <div class="identidade-usuario">
                        <h2>Usuário: <span class="cor-azul"><?= getNomeUsuario()?></span></h2>
                    
                        <a href="logout.php" class="btn-reclamacao">Logout</a>
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <div class="div-create">
            <a href="relatos-create.php?tipo=sugestao" class="btn">Nova sugestão</a>
            <a href="relatos-create.php?tipo=elogio" class="btn btn-elogio">Novo elogio</a>
            <a href="relatos-create.php?tipo=reclamacao" class="btn btn-reclamacao">Nova reclamação</a>
            <?php if ($isAdminOrAnalista): ?>
                <a href="relatos.php" class="btn btn-outros">Exibir relatos</a>
            <?php endif; ?>
        </div>

    </main>
</body>

</html>